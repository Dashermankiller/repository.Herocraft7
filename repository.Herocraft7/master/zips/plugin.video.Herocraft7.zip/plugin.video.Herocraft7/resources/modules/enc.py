import base64
import os
#https://herocraft7.ddns.net/archive/old/Anime_links.json
eng_url=base64.b64decode("YlhsNWRYZzZMeTl0YW5kMGFIZG1hM2szTG1scGMzZ3VjMnA1TDJaM2FHMXVZV292ZEhGcEwycHpiQzV2ZUhSeg"+"==")
ind_url=base64.b64decode("YlhsNWRYZzZMeTl0YW5kMGFIZG1hM2szTG1scGMzZ3VjMnA1TDJaM2FHMXVZV292ZEhGcEwyNXphUzV2ZUhSeg"+"==")
pak_url=base64.b64decode("YlhsNWRYZzZMeTl0YW5kMGFIZG1hM2szTG1scGMzZ3VjMnA1TDJaM2FHMXVZV292ZEhGcEwzVm1jQzV2ZUhSeg"+"==")
Anime_links=base64.b64decode("YlhsNWRYZzZMeTl0YW5kMGFIZG1hM2szTG1scGMzZ3VjMnA1TDJaM2FHMXVZV292ZEhGcEwyWnpibkpxWDNGdWMzQjRMbTk0ZEhNPQ"+"==")
def encr(text):
	key = 'abcdefghijklmnopqrstuvwxyz'
	def encrypt(n, plaintext):
		result = ''
		for l in plaintext.lower():
			try:
				i = (key.index(l) + n) % 26
				result += key[i]
			except ValueError:
				result += l
		return result.lower()

	def decrypt(n, ciphertext):
		result = ''
		for l in ciphertext:
			try:
				i = (key.index(l) - n) % 26
				result += key[i]
			except ValueError:
				result += l
		return result
	decrypted = decrypt(5, base64.b64decode(text))
	tes = decrypted
	return tes