import xbmc,sys
import xbmcvfs
import base64
import re
#import enc
import os           # access operating system commands
import urlparse     # splits up the directory path - much easier importing this than coding it up ourselves
import xbmc         # the base xbmc functions, pretty much every add-on is going to need at least one function from here
import xbmcaddon    # pull addon specific information such as settings, id, fanart etc.
import xbmcgui      # gui based functions, contains things like creating dialog pop-up windows
import xbmcplugin   # contains functions required for creating directory structure style add-ons (plugins)
import urllib2
import urllib
import urlparse
import cProfile
import pstats
import requests
from requests.auth import HTTPBasicAuth
try:
	import StorageServer
except:
	import storageserverdummy as StorageServer
cache = StorageServer.StorageServer("plugin.video.Herocraft7", 24) # (Your plugin name, Cache time in hours)
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP
import datetime
#import urlresolver
#import zipfile
# (*) = These modules require the noobsandnerds repo to be installed
import koding       # (*) a framework for easy add-on development, this template is to be used in conjunction with this module.
from koding import Add_Dir  # By importing something like this we don't need to use <module>.<function> to call it,
                            # instead you can just use the function name - in this case Add_Dir().
from koding import route, Run # These are essential imports which allow us to open directories and navigate through the add-on.
from xml.sax.saxutils import escape
import json
from enc import encr as eb
#----------------------------------------------------------------
#icon = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRwgZta5v7alk3c906ImM96oAEcXW_ocQhg_q1vnLfyFGT9Czdt'
player = xbmc.Player()
addon_id     = xbmcaddon.Addon().getAddonInfo('id') # Grab our add-on id
dialog       = xbmcgui.Dialog()                     # A basic dialog message command
home_folder  = xbmc.translatePath('special://home/')# Convert the special path of Kodi home folder to the physical path
addon_folder = os.path.join(home_folder,'addons')   # Join our folder above with 'addons' so we have a link to our addons folder
art_path     = os.path.join(addon_folder,addon_id)  # Join addons folder with the addon_id, we'll use this as a basic art folder
debug        = koding.Addon_Setting('debug')        # Grab the setting of our debug mode in add-on settings
regex        = koding.Addon_Setting('regexon')  
print"KODI SETTING",regex
addon_handle = int(sys.argv[1])
#-----------------------------------------------------------
# EDIT THIS MAIN_MENU() FUNCTION - THIS IS FUN TO PLAY WITH!
#-----------------------------------------------------------
#url_ewe ="http://5.9.70.82:8088/live/geoUsuper/playlist.m3u8?id=29309&pk=15923e737b4621953694e65c3463f3dd865b3a9503be6b3709cd44a7f66a06a7"
#url_her = 'https://herocraft7.ddns.net/archive/old/regex1.txt'
import urllib2
_addon = xbmcaddon.Addon()
_icon = _addon.getAddonInfo('icon')
from enc import *
#print encr(text3)
ls = ind_url,eng_url,pak_url,Anime_links
a,b,g,c=ls
#print a
#print c,"ddd"
text=c
Anime_links=encr(text)
#print Anime_links,"ANIME!!!!"
#print b
#print g
text=a
ind_url =encr(text)
text=c
Anime_links=encr(text)
text=b
eng_url=encr(text)
text=g
pak_url=encr(text)
##############################################################################################################
from urllib import unquote
from koding import route, Add_Dir, Addon_Setting, Data_Type, Find_In_Text
from koding import Open_URL, OK_Dialog, Open_Settings, Play_Video, Run, Text_File
from urllib2 import Request, urlopen, HTTPError, URLError
import urllib2
import urllib
import requests
