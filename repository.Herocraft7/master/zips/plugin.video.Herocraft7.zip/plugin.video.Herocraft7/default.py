from resources.modules.imports import *
#if len(stream_list) > 1:
 #       select_list = []
  #      for stream in stream_list:
   #         print "STREAM@##",stream
    #        select_list.append(b64decode(stream.get("Bc3RyZWFtX3VybA==")[1:]))
     #       print "SELECTED",select_list
      #  dialog = xbmcgui.Dialog()
       # ret = dialog.select("Choose Stream", select_list)
       # selected_stream = stream_list[ret]
#from imports import *
import cProfile
import pstats
#import multiprocessing 
import requests
from threading import Thread
#from multiprocessing.pool import ThreadPool
from requests.auth import HTTPBasicAuth	
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP
import urllib
import urllib2
dialog = xbmcgui.Dialog()
regexon= koding.Addon_Setting('regexon')
passwd= koding.Addon_Setting('enter_some')
user=koding.Addon_Setting('username')
#print"Enter_SOME",passwd,user
pak_on= koding.Addon_Setting('pak_on')
regex= koding.Addon_Setting('regex_on')
url= koding.Addon_Setting('url_on')
ind_on= koding.Addon_Setting('ind_on')
eng_on= koding.Addon_Setting('eng_on')
movies_on= koding.Addon_Setting('movies_on')
server = koding.Addon_Setting('id_addon')    
debug = koding.Addon_Setting('debug') 
from xbmcgui import ListItem
if __name__ == "__main__":
	def play(title,path):
		from base64 import *
		stream=path
		dict2 = eval(stream)
		stream_list=list(dict2)
		print path
		print "LIST@#@@@@@@@@@@",stream_list
		ret = dialog.select("Choose Stream", stream_list)
		path = stream_list[ret]
		print "SELECTED:",path
		pla(title,path,'#')

	def req1 (url,regex=None):
		if url ==None or regex ==None :
			print "No URL found"
		else:
		   pass
		#print "input",url
		if url.endswith(".m3u8"):
			return url
		else:
			pass
		print "regex#@",regex
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; rv:14.0) Gecko/20100101 Firefox/14.0.1')
		req.add_header('Referer', url)
		response = urllib2.urlopen(req)
		link22 = response.read()
		return link22
	@route(mode="doregex",args=["regex","url"])
	def doregex(regex,url):
		regex=regex
		try:
			link3=req1(url)
			if link3.endswith(".m3u8"): 
				return link3
			else:
				print link3
			#print 'LINK3_re',type(link3)
			#print "LINK3_regex", regex
			try:
				match_regex = re.compile(regex).findall(link3)
				#print "TEST1232", match_regex
			except:
				match_regex = re.compile(regex).findall(link3)
				#print "TEST1232", match_regex
		except:
			print match_regex,match_regex2
		try:
			match_regex = re.compile(regex).findall(link3)
			print match_regex[0]
		except:
			match_regex = re.compile(regex).findall(link3)
			print match_regex[0]
		finally:
			try:
				#print "LEN",match_regex
				if len(match_regex) > 1:
					print "match_regex",match_regex[1]
					data=match_regex[1]
					return data
				else:
					print "match_regex2",match_regex[0]
					data=match_regex[0]
					return data
			except IndexError:
				print "No regex found"
				return ""
				
				
	def auth_link(url,user=str(user),passwd=str(passwd)):
		print passwd,user,url
		from requests import session
		payload = {'action': 'login','username': user,'password': passwd}
		with session() as c:
			c.post(url,data=payload)
			response = c.get(url)
			print(response.headers)
			print(response.text)
	#url_link1="https://herocraft7.ddns.net/archive/img/03%20Valima.m4v"
	##print url_link1,user,passwd

	#link=auth_link(url_link1,user,passwd)



	#print "LIN#$@#@#@#@",link
	def opem_url2(eng_url):
		req = urllib2.Request(eng_url)
		#xbmc.log('### CONTENTS: %s'% req)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0')
		response = urllib2.urlopen(req)
		link = response.read()
		#xbmc.log('### CONTENTS_link: %s'% link)
		response.close()
		#xbmc.log('### CONTENTS_li2nk: %s'% response)
		#return link
		return link.replace('\n','').replace('\r','\n')	
	def pla(title,url,icon):
		li = xbmcgui.ListItem(title, iconImage=icon)
		xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

	def pak(pak_url):
		req = urllib2.Request(pak_url)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0')
		response = urllib2.urlopen(req)
		link = response.read()
		response.close()
		#return link
		return link.replace('\n','').replace('\r','\n')	
	def pla(title,url,icon):
		li = xbmcgui.ListItem(title, iconImage=icon)
		xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
		
	def pak(ind_url):
		req = urllib2.Request(ind_url)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0')
		response = urllib2.urlopen(req)
		link = response.read()
		response.close()
		return link.replace('\n','').replace('\r','\n')	
	def pla(title,url,icon):
		li = xbmcgui.ListItem(title, iconImage=icon)
		xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)


	def opem_url(url_her):
		req = urllib2.Request(url_her)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0')
		response = urllib2.urlopen(req)
		link = response.read()
		response.close()
		#return link
		return link.replace('\n','').replace('\r','\n')	
	def pla(title,url,icon):
		li = xbmcgui.ListItem(title, iconImage=icon)
		xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

	def opem_urlp(url_her):
		req = urllib2.Request(url_her)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0')
		response = urllib2.urlopen(req)
		link = response.read()
		response.close()
		return link
		#return link.replace('\n','').replace('\r','\n')	
	def pla(title,url,icon):
		li = xbmcgui.ListItem(title, iconImage=icon)
		xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

	#########################################################################################################	
	#url = ''
	#mode = 'channels'

	#xbmc.log("#####TEST#### %s"% str(addon_handle))
	#xbmcplugin.setContent(addon_handle, 'movies')



	def addDir(dir_type, mode, url, name, icon):
		base_url = sys.argv[0]
		xbmc.log("##### AGVE %s"% base_url)
		base_url += "?url="+url
		base_url += "&mode=" +str(mode)
		base_url += "&name=" +name
		base_url += "&icon=" +icon
		full_url = base_url.split('&mode=')
		#xbmc.log ('#####FULL###%s'% (str(full_url)))
		#xbmc.log("#####TEST2#### %s"% str(base_url))
		li = xbmcgui.ListItem(name, iconImage=icon)

		if dir_type != '':
			link = xbmcplugin.addDirectoryItem(handle=addon_handle,url=base_url,listitem=li,isFolder=True)
		else:
			link = xbmcplugin.addDirectoryItem(handle=addon_handle,url=url,listitem=li,isFolder=False)
		return link

	def f4m():
		pass
		
	#=============================================================================================================	

	@route(mode="english")
	def english():
		content = opem_url2(eng_url)
		#xbmc.log('### CONTENTS32: %s'% content)
		try:
			matches2 = re.compile("'title':\s'(.+)'| 'link':\s'(.+)'|'thumbnail':\s'(.+)'|'Page':'(.+)'|'referer':'(.+)'|'regex':(.+)").findall(content)
		finally:
			matches = re.compile('"title": "(.+?)",\n\s+"link":\s"(.+?)",\n\s+"thumbnail":\s"(.+?)"').findall(content)
		
		if matches == 0:
			content = opem_urlp(eng_url)
			#xbmc.log('### CONTENTS34: %s'% content)
			matches = re.compile('"title": "(.+?)",\n\s+"link":\s"(.+?)",\n\s+"thumbnail":\s"(.+?)"').findall(content)
			return matches
			
		#matches = re.compile('name ="(.+?)"\npath ="(.+?)"\nthumb ="(.+?)\nfanart ="(.+?)').findall(content)
		#xbmc.log('###MATICHES %s' % matches)	
		for item in matches:
			name = (item[0])
		#	print name
			path = (item[1])
			thumb = (item[2])
			print path
			pla(name,path,thumb)
			

	@route(mode="Channels")
	def channels():
		content = opem_url(url_her)
		#xbmc.log('### CONTENTS: %s'% content)
		matches = re.compile('"title": "(.+?)",\n\s+"link":\s"(.+?)",\n\s+"thumbnail":\s"(.+?)"').findall(content)
		#matches = re.compile('name ="(.+?)"\npath ="(.+?)"\nthumb ="(.+?)\nfanart ="(.+?)').findall(content)
		#xbmc.log('###MATICHES %s' % matches)	
		for item in matches:
			name = (item[0])
			path = (item[1])
			thumb = (item[2])
			pla(name,path,thumb)
			livetv = pla
	@route(mode="Pakistan")	
	def Pakistan():
		use_url= koding.Addon_Setting('user_link')
		import ast
		regex1=None
		regex2=None
		regex=None
		url=None
		thumb=None
		title=None
		link=None
		content = opem_url2(pak_url)
		#xbmc.log('### CONTENTS_pak: %s'% content)
		try:
			matches2 = re.compile("'title': '(.+?)',\n\s+'link':\s'(.+?)',\n\s+'thumbnail':\s'(.+?)',\n\s\s+'regex':\[(.+)]").findall(content)
		finally:
			matches = re.compile("'title': '(.+?)',\n\s+'link':\s(.+),\s\s+'thumbnail':\s'(.+?)'").findall(content)
		for item in matches:
			name = (item[0])
			path = (item[1]).replace("'","")
			thumb = (item[2])
			print path
			#name=name.sort()
			if name.endswith("(regex)"):
				if str(regexon) =="true":
					#print "KODI_regex",regexon
					continue
			else:
				
				pla(name,path,thumb)
				
		if str(regexon) =="true":
			print "KODI_regex",regexon	
			for item2 in matches2:
					title = (item2[0])
					link = (item2[1])
					thumb = (item2[2])
					regex = "{"+(item2[3]) +"}"
					#regex={regex}
					print "FULLREGEX",regex
					#regex=regex.replace("'", '"')
					print type(regex)
					regex= ast.literal_eval(regex)
					print type(regex)
					#print regex
					url=regex['url']
					link2=regex['page']
					regex1=regex['regex']
					regex2=regex['regex2']
					regex3=regex['regex3']
					if use_url =="true":
						pla(title,link,thumb)
					else:
						try:
							test=doregex(regex1,url)
							print "TEST_doregex12",test
							if "m3u8" in test:
								print "link has m3u8",test
							else:
								pass
							test=doregex(regex2,test)
							m3u8=doregex(regex3,url)
							print "Finished","http://"+test+m3u8
							try:
								m3u8="http://"+test+m3u8
								print "Finished","http://",m3u8
								if m3u8.startswith("https://"):
									pla(title,m3u8,thumb)
									livetv = pla
								else:
									m3u8=m3u8.replace('http:///','http://')
									pla(title,m3u8,thumb)
									livetv = pla
							except:
								m3u8=m3u8
								pla(title,m3u8,thumb)
								livetv = pla
						except:
							print "ERROR:" " " + "NO REGEX FOUND: THIS CAN BE SEEN IN THE LOG"
						else:
							pass
	@route(mode="India")						
	def India():
		content = opem_url(ind_url)
		#xbmc.log('### CONTENTS: %s'% content)
		matches = re.compile('"title": "(.+?)",\n\s+"link":\s"(.+?)",\n\s+"thumbnail":\s"(.+?)"').findall(content)
		#matches = re.compile('"title": "(.+?)",\n\s+"link":\s"(.+?)",\n\s+"thumbnail":\s"(.+?)"').findall(content)
		#matches = re.compile('name ="(.+?)"\npath ="(.+?)"\nthumb ="(.+?)\nfanart ="(.+?)').findall(content)
		xbmc.log('###MATICHES %s' % matches)	
		for item in matches:
			name = (item[0])
			path = (item[1])
			thumb = (item[2]) 
			pla(name,path,thumb)
			livetv = pla	
	@route(mode="main")
	def main_menu():
		thumb=""
		if str(eng_on) =="true":
			addDir('folder','english','','English','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTs6agCqYZRqm83ZI3DDYYdCb1643Mol72w0qHhgjltNuYFoq57')
		if str(pak_on) =="true":
			addDir('folder','Pakistan','','Pakistan','http://moziru.com/images/pakistan-clipart-pakistani-flag-11.jpg')
		if str(ind_on) =="true":
			addDir('folder','India','','India','http://logos.flamingtext.com/Country-Logos/IN-Logo.png')
		if str(movies_on) =="true":
			addDir('folder','Movies','','Movies','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTDRFTELdCDaNu3dSmDN7Np91Giwwecpg6nNT3wKYDUJ8uVx4hltg')
		else:
			pass
	#pla(title ="test",url =url_ewe,icon = thumb)

	main_xml     = 'https://herocraft7.ddns.net/archive/old/Movies.xml'
	@route(mode="Movies")
	def raw(url=main_xml):
		if url.startswith('http'):
			contents  = Open_URL(url)
		else:
			contents  = Text_File(url,'r')

		contents = contents.replace('\n','').replace('\t','')
		raw_links = Find_In_Text(content=contents, start='<item>', end=r'</item>')
		xbmc.log(repr(raw_links),2)
		counter = 1
		for item in raw_links:
			xbmc.log('# Checking link %s'%counter,2)
			counter += 1
			title  = Find_In_Text(content=item, start='<title>', end=r'</title>')
			title  = title[0] if (title!=None) else 'Unknown Video'
			thumb  = Find_In_Text(content=item, start='<thumbnail>', end=r'</thumbnail>')
			thumb  = thumb[0] if (thumb!=None) else ''
			fanart = Find_In_Text(content=item, start='<thumbnail>', end=r'</thumbnail>')
			fanart = fanart[0] if (fanart!=None) else ''
		# If this contains sublinks grab all of them
			if not '<sublink>' in item:
				links  = Find_In_Text(content=item, start='<link>', end=r'</link>')
				link=links
				link=''.join(link)
				xbmc.log('# Checking link22 %s'%link)
				li = xbmcgui.ListItem(title, iconImage=thumb)
				link=xbmcplugin.addDirectoryItem(handle=addon_handle,url=link,listitem=li,isFolder=False)

	#mode = None
	#argv = sys.argv[2]
	#	if len(argv) > 0:
	#	mode = argv.split('mode=')
	#	xbmc.log(str(mode))
	#	mode = mode[1].split('&')
	#	xbmc.log(str(mode))
	#	mode=mode[0]
	#		xbmc.log(str(mode))



	#if mode ==None:main_menu()
	#elif mode == 'channels':channels()
	#elif mode == 'english':english()
	#elif mode == 'Pakistan':Pakistan()
	#elif mode == 'India':India()
	#elif mode == 'Movies':raw()


Run(default='main')
xbmcplugin.endOfDirectory(int(sys.argv[1]))
	#xbmcplugin.endOfDirectory(addon_handle)

